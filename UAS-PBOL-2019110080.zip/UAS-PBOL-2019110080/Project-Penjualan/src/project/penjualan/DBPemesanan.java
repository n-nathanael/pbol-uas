/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.penjualan;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author LIKMI
 */
public class DBPemesanan {

    private PemesananModel dt = new PemesananModel();
    private HashMap<String, PemesanandetilModel> dt2 = new HashMap<String, PemesanandetilModel>();

    public PemesananModel getPemesananModel() {
        return (dt);
    }

    public void setPemesananModel(PemesananModel s) {
        dt = s;
    }

    public HashMap<String, PemesanandetilModel> getPemesanandetilModel() {
        return (dt2);
    }

    public void setPemesanandetilModel(PemesanandetilModel d) {
        dt2.put(d.getKodebrg(), d);
    }

    public ObservableList<PemesananModel> Load() {
        try {
            ObservableList<PemesananModel> tableData = FXCollections.observableArrayList();
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("Select p.nopesan,p.pesan,c.idcust, c.nama from pesan p join customer c on(p.idcust=c.idcust)");
            int i = 1;
            while (rs.next()) {
                PemesananModel d = new PemesananModel();
                d.setNopesan(rs.getString("nopesan"));
                d.setTgl(rs.getDate("tgl"));
                d.setIdcust(rs.getString("idcust"));
                d.setNama(rs.getString("nama"));

                tableData.add(d);
                i++;
            }
            con.tutupKoneksi();
            return tableData;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int validasi(String nomor) {
        int val = 0;
        try {
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("select count(*) as jml from jual where nopesan = '" + nomor + "'");
            while (rs.next()) {
                val = rs.getInt("jml");
            }
            con.tutupKoneksi();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return val;
    }

    public boolean insert() {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("insert into pemesanan (nopesan, tgl, idcust, nama) values (?,?,?,?)");
            con.preparedStatement.setString(1, getPemesananModel().getNopesan());
            con.preparedStatement.setDate(2, getPemesananModel().getTgl());
            con.preparedStatement.setString(3, getPemesananModel().getIdcust());
            con.preparedStatement.setString(4, getPemesananModel().getNama());
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
            berhasil = false;
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public boolean delete(String nomor) {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();;
            con.preparedStatement = con.dbKoneksi.prepareStatement("delete from pemesanan where nopesan  = ? ");
            con.preparedStatement.setString(1, nomor);
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public boolean update() {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("update pemesanan set tanggal = ?, idmember = ?  where  nopesan= ? ");
            con.preparedStatement.setDate(1, getPemesananModel().getTgl());
            con.preparedStatement.setString(2, getPemesananModel().getIdcust());
            con.preparedStatement.setString(3, getPemesananModel().getNopesan());
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
            berhasil = false;
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public ObservableList<PemesananModel> CariJual(String kode) {
        try {
            ObservableList<PemesananModel> tableData;
            tableData = FXCollections.observableArrayList();
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = (Statement) con.dbKoneksi.createStatement();
            ResultSet rs = (ResultSet) con.statement.executeQuery("select nopesan, tgl, idcust, nama from jual WHERE nopesan LIKE '" + kode + "%'");
            int i = 1;
            while (rs.next()) {
                PemesananModel d = new PemesananModel();
                d.setNopesan(rs.getString("nopesan"));
                d.setTgl(rs.getDate("tanggal"));
                d.setIdcust(rs.getString("idcust"));
                d.setIdcust(rs.getString("nama"));
            }
            con.tutupKoneksi();
            return tableData;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    void print() {
        Koneksi con = new Koneksi();
        String is = "./src/project/penjualan/reportJual1.jasper";
        Map map = new HashMap();
        map.put("p_periode", "Desember");
        con.bukaKoneksi();
        try {
            JasperPrint jasperPrint
                    = JasperFillManager.fillReport(is, map, con.dbKoneksi);
            JasperViewer.viewReport(jasperPrint, false);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        con.tutupKoneksi();
    }

    public String autonum(String tahun) {
        String tmp = "";
        try {
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery(
                    "select max(nojual) as n from pemesanan where nopesan like '" + tahun + "%'");
            while (rs.next()) {
                tmp = tahun
                        + String.format("%03d",
                                Integer.parseInt(rs.getString("n").substring(4)) + 1
                        );
            }
            con.tutupKoneksi();
            return tmp;
        } catch (Exception e) {
            e.printStackTrace();
            return tmp;
        }
    }

    public boolean saveall() {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.dbKoneksi.setAutoCommit(false); // membuat semua perintah menjadi 1 transaksi
            con.preparedStatement = con.dbKoneksi.prepareStatement("delete from pemesanan where nopesan=?");
            con.preparedStatement.setString(1, getPemesananModel().getNopesan());
            con.preparedStatement.executeUpdate();
            con.preparedStatement = con.dbKoneksi.prepareStatement("insert into pemesanan (nopesan,tgl,idcust) values (?,?,?)");
            con.preparedStatement.setString(1, getPemesananModel().getNopesan());
            con.preparedStatement.setDate(2, getPemesananModel().getTgl());
            con.preparedStatement.setString(3, getPemesananModel().getIdcust());
            con.preparedStatement.executeUpdate();
            con.preparedStatement = con.dbKoneksi.prepareStatement("delete from pemesanan_detil where nopesan=?");
            con.preparedStatement.setString(1, getPemesananModel().getIdcust());
            con.preparedStatement.executeUpdate();
            for (PemesanandetilModel sm : dt2.values()) {
                con.preparedStatement = con.dbKoneksi.prepareStatement("insert into pemesanan_detil (nopesan,kodebrg, jumlah) values (?,?,?)");
                con.preparedStatement.setString(1, sm.getNopesan());
                con.preparedStatement.setString(2, sm.getKodebrg());
                con.preparedStatement.setInt(3, sm.getJumlah());
                con.preparedStatement.executeUpdate();
            }
            con.dbKoneksi.commit();//semua perintah di transaksi dikerjakan
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
            berhasil = false;
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }
}
