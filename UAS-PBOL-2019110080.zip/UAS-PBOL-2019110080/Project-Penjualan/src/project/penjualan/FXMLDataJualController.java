/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package project.penjualan;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;

/**
 * FXML Controller class
 *
 * @author LIKMI
 */
public class FXMLDataJualController implements Initializable {

    @FXML
    private TableView<PemesananModel> tbvjual;
    @FXML
    private Button btnawal;
    @FXML
    private Button btnsesudah;
    @FXML
    private Button btnsebelum;
    @FXML
    private Button btnakhir;
    @FXML
    private Button btntambah;
    @FXML
    private Button btnupdate;
    @FXML
    private Button btnhapus;
    @FXML
    private TextField searchjual;
    @FXML
    private TextField txtnojual;
    @FXML
    private TextField txtidmember;
    @FXML
    private TableView<PemesanandetilModel> tbvdetil;
    @FXML
    private DatePicker dtptanggal;
    @FXML
    private TextField txttotal;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       showdata();
       tbvjual.getSelectionModel().selectFirst(); //ini untuk inisialisasi baris pertama
       tbvdetil.getSelectionModel().selectFirst();
       setdata();
    }    
    

    @FXML
    public void setdata(){
        txtnojual.setText(tbvjual.getSelectionModel().getSelectedItem().getNopesan());
        dtptanggal.setValue(tbvjual.getSelectionModel().getSelectedItem().getTgl().toLocalDate());
        txtidmember.setText(tbvjual.getSelectionModel().getSelectedItem().getIdcust());
        showdatadetil();
      }
    
    
    public void showdata(){
        ObservableList<PemesananModel> data=FXMLDocumentController.dtpesan.Load();
        if(data!=null){            
            tbvjual.getColumns().clear();            
            tbvjual.getItems().clear();
            TableColumn col=new TableColumn("NO.PESAN");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
            tbvjual.getColumns().addAll(col);
            col=new TableColumn("TGL");
            //col.setCellValueFactory(new PropertyValueFactory<JualModel, String>("tgl"));
            col.setCellValueFactory(new FormattedDateValueFactory<PemesananModel>("tgl", "dd-MMM-yyyy"));
            tbvjual.getColumns().addAll(col);
            col=new TableColumn("IDCUST");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("idcust"));
            tbvjual.getColumns().addAll(col);
            col=new TableColumn("NAMA");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nama"));
            tbvjual.getColumns().addAll(col);
                   
            tbvjual.setItems(data);
    }else {  Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvjual.getScene().getWindow().hide();;
        }                
    }
    
    
    public void showdatadetil(){
        
        ObservableList<PemesanandetilModel> data=FXMLDocumentController.dtpesandetil.Load(txtnojual.getText());
        if(data!=null){    
            
            tbvdetil.getColumns().clear();
            tbvdetil.getItems().clear();
            
            TableColumn col=new TableColumn("nojual");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("nopesan"));
            tbvdetil.getColumns().addAll(col);
            
            col=new TableColumn("kode barang");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("kodebrg"));
            tbvdetil.getColumns().addAll(col);
            
            col=new TableColumn("nama barang");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("namabrg"));
            tbvdetil.getColumns().addAll(col);
            
            col=new TableColumn("jumlah");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("jumlah"));
            tbvdetil.getColumns().addAll(col);
            
            col=new TableColumn("tarif");
            //col.setCellValueFactory(new PropertyValueFactory<JualdetilModel, String>("tarif"));
            col.setCellValueFactory(new FormattedDouble<PemesanandetilModel>("tarif","#,###,##0"));
            tbvdetil.getColumns().addAll(col);
            
            col=new TableColumn("total");
            //col.setCellValueFactory(new PropertyValueFactory<JualdetilModel, String>("total"));
            col.setCellValueFactory(new FormattedDouble<PemesanandetilModel>("total","#,###,##0"));
            tbvdetil.getColumns().addAll(col);
            
            tbvdetil.setItems(data);
            
            double totalall=0;
            for(int i=0;i<tbvdetil.getItems().size();i++){
		PemesanandetilModel n=tbvdetil.getItems().get(i);
		totalall+=n.getTotal();
            }
            txttotal.setText(String.valueOf(totalall));

            
    }else {  Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvdetil.getScene().getWindow().hide();;
        }     
    }
    
    @FXML
    private void cariData(KeyEvent event) {
        PemesananModel s = new PemesananModel();
        String key = searchjual.getText();
        if(key!=""){
        ObservableList<PemesananModel> data=FXMLDocumentController.dtpesan.CariJual(key);
        ObservableList<PemesanandetilModel>
                data2=FXMLDocumentController.dtpesandetil.CariDetil(key);
        
        if(data!=null){            
            tbvjual.getColumns().clear();            
            tbvjual.getItems().clear();
            TableColumn col=new TableColumn("NO.PESAN");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
            tbvjual.getColumns().addAll(col);
            col=new TableColumn("TGL");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("tgl"));
            tbvjual.getColumns().addAll(col);
            col=new TableColumn("IDCUT");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("idcust"));
            tbvjual.getColumns().addAll(col);   
            tbvjual.setItems(data);
            
            
            
            tbvdetil.getColumns().clear();
            tbvdetil.getItems().clear();
            TableColumn col2=new TableColumn("NO.PESAN");
            col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
            tbvdetil.getColumns().addAll(col2);
            col2=new TableColumn("KODE BRG");
            col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("kodebrg"));
            tbvdetil.getColumns().addAll(col2);
            col2=new TableColumn("jumlah");
            col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("jumlah"));
            tbvdetil.getColumns().addAll(col2);
            col2=new TableColumn("tarif");
            col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("tarif"));
            tbvdetil.getColumns().addAll(col2);
            col2=new TableColumn("total");
            col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("total"));
            tbvdetil.getColumns().addAll(col2);
            tbvdetil.setItems(data2);
            
        }else {
            Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvjual.getScene().getWindow().hide();;
        }            
            } else{
               showdata();
            }  
    }

    @FXML
    private void akhirklik(ActionEvent event) {
        tbvjual.getSelectionModel().selectLast();    
        tbvjual.requestFocus(); 
        setdata();
    }

    @FXML
    private void sebelumklik(ActionEvent event) {
        tbvjual.getSelectionModel().selectAboveCell();       
        tbvjual.requestFocus(); 
        setdata();
    }

    @FXML
    private void sesudahklik(ActionEvent event) {
        tbvjual.getSelectionModel().selectBelowCell();        
        tbvjual.requestFocus();
        setdata();
    }

    @FXML
    private void awalklik(ActionEvent event) {
      tbvjual.getSelectionModel().selectFirst();        
      tbvjual.requestFocus(); 
      setdata();
    }

    @FXML
    private void tambahklik(ActionEvent event) {
    }

    @FXML
    private void updateklik(ActionEvent event) {
    }

    @FXML
    private void hapusklik(ActionEvent event) {
    }

  
}
