/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package project.penjualan;

import java.net.URL;
//import java.util.Date;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author LIKMI
 */
public class FXMLSimulasiController implements Initializable {

    @FXML
    private ListView<String> lstpelanggan;
    @FXML
    private ListView<String> lstbarang;
    @FXML
    private TextField txtwaktu;
    @FXML
    private Button btnsimulasi;
    @FXML
    private TextArea txatransaksi;
    
    Random acak = new Random();
    Timer t = new Timer();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy");


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txatransaksi.setWrapText(true);
        lstpelanggan.getItems().clear(); 
        lstbarang.getItems().clear();
        
        ObservableList<CustModel> data=FXMLDocumentController.dtcust.Load();
        if(data.isEmpty()){
            Alert a=new Alert(Alert.AlertType.ERROR,"Data Customer Kosong",ButtonType.OK);
            a.showAndWait();
            txatransaksi.getScene().getWindow().hide();
        }else {
            for(int i=0;i<data.size();i++){
              lstpelanggan.getItems().addAll(data.get(i).getIdcust()+" - "+data.get(i).getNama());
            }  
        
        ObservableList<BrgModel> data2=FXMLDocumentController.dtbrg.Load();
            if(data.isEmpty()){
               Alert a=new Alert(Alert.AlertType.ERROR,"Data Barang Kosong",ButtonType.OK);
               a.showAndWait();
               txatransaksi.getScene().getWindow().hide();;
            }else {
                for(int i=0;i<data2.size();i++){
              lstbarang.getItems().addAll(data2.get(i).getKodebrg()+" - "+data2.get(i).getNamabrg());
                }
            }
        }    
    }    

    @FXML
    private void simulasiklik(ActionEvent event) {
        int wkt=Integer.parseInt(txtwaktu.getText());        
        t.scheduleAtFixedRate(
                new TimerTask(){           
                    @Override 
                    public void run(){       
                        Platform.runLater(() -> {
                        int p=acak.nextInt(lstpelanggan.getItems().size());
                        int b=acak.nextInt(lstbarang.getItems().size());
                        int jml=acak.nextInt(10)+1; 
                        
                        PemesananModel j=new PemesananModel();
                        j.setNopesan(FXMLDocumentController.dtpesan.autonum(sdf.format(new java.util.Date())) );        
                        j.setIdcust(lstpelanggan.getItems().get(p).substring(0, 5));//sesuaikan dgn idmember DB
                        j.setTgl(Date.valueOf(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
        
                        PemesanandetilModel s=new PemesanandetilModel();      
                        s.setNopesan(j.getNopesan());
                        s.setKodebrg(lstbarang.getItems().get(b).substring(0, 6));//sesuaikan dgn kodebrg DB
                        s.setJumlah(jml);
                        FXMLDocumentController.dtpesan.setPemesananModel(j);
                        FXMLDocumentController.dtpesan.setPemesanandetilModel(s);
                        
                        if (FXMLDocumentController.dtpesan.saveall()){
                        txatransaksi.setText(txatransaksi.getText()+
                        j.getNopesan()+" - "+    lstpelanggan.getItems().get(p)+" : "+
                        lstbarang.getItems().get(b)+" "+String.format("%d\n", jml) );
                        txatransaksi.setScrollTop(Double.MAX_VALUE);        }
          
                        });
                    }        
                }, 0, 60000*wkt);            
    }
}
    
