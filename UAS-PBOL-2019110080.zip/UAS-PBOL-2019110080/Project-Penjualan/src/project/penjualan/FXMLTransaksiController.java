/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package project.penjualan;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author LIKMI
 */
public class FXMLTransaksiController implements Initializable {

    boolean buattrans=false;
   
    private TableView<CustModel> tbvcust;
    @FXML
    private TableView<BrgModel> tbvbarang;
    @FXML
    private TableView<PemesanandetilModel> tbvdetil;
    @FXML
    private TextField txtnojual;
    @FXML
    private DatePicker dtptanggal;
    @FXML
    private TextField txtidmember;
    @FXML
    private TextField txtkodebrg;
    @FXML
    private TextField txtjumlah;
    @FXML
    private Button btntambahbrg;
    @FXML
    private Button btnhapusbrg;
    @FXML
    private Button btnbatal;
    @FXML
    private Button btnsimpan;
    @FXML
    private Button btnhapustrans;
    @FXML
    private TextField txttotal;
    @FXML
    private Button btnpilihcust;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //showdatacust();
        showdatabrg();
        
    }    

    public void showdatacust(){
        ObservableList<CustModel> data=FXMLDocumentController.dtcust.Load();
        if(data!=null){            
            tbvcust.getColumns().clear();            
            tbvcust.getItems().clear();
            TableColumn col=new TableColumn("kodePeserta");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("idcust"));
            tbvcust.getColumns().addAll(col);
            col=new TableColumn("namaPeserta");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("nama"));
            tbvcust.getColumns().addAll(col);
            col=new TableColumn("alamatPeserta");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("alamat"));
            tbvcust.getColumns().addAll(col);
                        
            tbvcust.setItems(data);
    }else {  Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvcust.getScene().getWindow().hide();;
        }                
    }
    
    public void showdatabrg(){
        ObservableList<BrgModel> data=FXMLDocumentController.dtbrg.Load();
        if(data!=null){            
            tbvbarang.getColumns().clear();            
            tbvbarang.getItems().clear();
            TableColumn col=new TableColumn("kodeKelas");
            col.setCellValueFactory(new PropertyValueFactory<BrgModel, String>("kodebrg"));
            tbvbarang.getColumns().addAll(col);
            col=new TableColumn("namaKelas");
            col.setCellValueFactory(new PropertyValueFactory<BrgModel, String>("namabrg"));
            tbvbarang.getColumns().addAll(col);
            col=new TableColumn("biayaKelas");
            col.setCellValueFactory(new FormattedDouble<BrgModel>("tarif","#,###,##0"));
            //col.setCellValueFactory(new PropertyValueFactory<BrgModel, String>("tarif"));
            tbvbarang.getColumns().addAll(col);
                   
            tbvbarang.setItems(data);
    }else {  Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvbarang.getScene().getWindow().hide();;
        }                
    }
    
    public void showdatadetil(){
        
        ObservableList<PemesanandetilModel> data=FXMLDocumentController.dtpesandetil.Load(txtnojual.getText());
        if(data!=null){    
                  
            tbvdetil.getColumns().clear();
            tbvdetil.getItems().clear();
            TableColumn col=new TableColumn("noPendaftaran");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
            tbvdetil.getColumns().addAll(col);
            col=new TableColumn("kodeKelas");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("kodebrg"));
            tbvdetil.getColumns().addAll(col);
            col=new TableColumn("biayaKelas");
            //col.setCellValueFactory(new PropertyValueFactory<JualModel, String>("tarif"));
            col.setCellValueFactory(new FormattedDouble<PemesananModel>("tarif","#,###,##0"));
            tbvdetil.getColumns().addAll(col);
            col=new TableColumn("totalBiaya");
            //col.setCellValueFactory(new PropertyValueFactory<JualModel, String>("total"));
            col.setCellValueFactory(new FormattedDouble<PemesananModel>("total","#,###,##0"));  
            tbvdetil.getColumns().addAll(col);
            tbvdetil.setItems(data);
            
            double totalall=0;
            for(int i=0;i<tbvdetil.getItems().size();i++){
		PemesanandetilModel n=tbvdetil.getItems().get(i);
		totalall+=n.getTotal();
            }
            txttotal.setText(String.valueOf(totalall));
    }else {  Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvdetil.getScene().getWindow().hide();;
        }     
    }
    
    @FXML
    private void tambahbrgklik(ActionEvent event) {
      
    if( !buattrans){
        Alert a=new Alert(Alert.AlertType.ERROR,
                "Mohon klik Buat Transaksi",ButtonType.OK);
        a.showAndWait();
    }
    else {
        //detil
        PemesanandetilModel d=new PemesanandetilModel();        
        d.setNopesan(txtnojual.getText());
        d.setKodebrg(txtkodebrg.getText());
        d.setJumlah(Integer.parseInt(txtjumlah.getText())); 
        
        FXMLDocumentController.dtpesandetil.setPemesanandetilModel(d);
        if(FXMLDocumentController.dtpesandetil.insert()){
            Alert a=new Alert(
                    Alert.AlertType.INFORMATION,"Kelas berhasil ditambah",ButtonType.OK);
            a.showAndWait();
        } else {
            Alert a=new Alert(Alert.AlertType.ERROR,"Kelas gagal ditambah",ButtonType.OK);
            a.showAndWait();
        }
        showdatadetil();
    }
    }

    @FXML
    private void hapusbrgklik(ActionEvent event) {
        PemesanandetilModel s= new PemesanandetilModel();       
        Alert a=new Alert(Alert.AlertType.CONFIRMATION,
                "Barang akan dihapus?",ButtonType.YES,ButtonType.NO);
        a.showAndWait();
        if(a.getResult()==ButtonType.YES){
           if(FXMLDocumentController.dtpesandetil.delete
                        (txtnojual.getText(),txtkodebrg.getText())){
               Alert b=new Alert(Alert.AlertType.INFORMATION,
                       "Barang berhasil dihapus", ButtonType.OK);
               b.showAndWait();
           } else {
               Alert b=new Alert(Alert.AlertType.ERROR,"Gagal dihapus",
                                 ButtonType.OK);
               b.showAndWait();               
           }    
           showdatadetil(); 
        }
    }

    @FXML
    private void batalklik(ActionEvent event) {
        txtnojual.setText("");
        txtidmember.setText("");
        txtkodebrg.setText("");
        txtjumlah.setText("");
        dtptanggal.getEditor().clear();
        showdatacust();
        showdatabrg();
        showdatadetil();
        tbvcust.getSelectionModel().selectFirst(); 
        tbvbarang.getSelectionModel().selectFirst();
        buattrans=false;
    }
      
    @FXML
    private void simpanklik(ActionEvent event){
          //master
            PemesananModel n = new PemesananModel();
            n.setNopesan(txtnojual.getText());
            n.setTgl(Date.valueOf(dtptanggal.getValue()));
            n.setIdcust(txtidmember.getText());
            
            FXMLDocumentController.dtpesan.setPemesananModel(n);
            if(FXMLDocumentController.dtpesan.insert()){
                buattrans = true;
                Alert a=new Alert(Alert.AlertType.INFORMATION,
                        "Transaksi berhasil dibuat",ButtonType.OK);
                a.showAndWait();
                //batalklik();
            } else {
                Alert a=new Alert(Alert.AlertType.ERROR,
                        "Transaksi gagal dibuat",ButtonType.OK);
                a.showAndWait();            
            }
        }

    private void settxtidmember(MouseEvent event) {
        txtidmember.setText(tbvcust.getSelectionModel().getSelectedItem().getIdcust());
    }

    @FXML
    private void settxtkodebrg(MouseEvent event) {
        txtkodebrg.setText(tbvbarang.getSelectionModel().getSelectedItem().getKodebrg());
    
    }

    @FXML
    private void sethapusbarang(MouseEvent event) {
        txtkodebrg.setText(tbvdetil.getSelectionModel()
                  .getSelectedItem().getKodebrg());
        txtjumlah.setText(String.valueOf(
                tbvdetil.getSelectionModel().getSelectedItem().getJumlah()));
    }

    @FXML
    private void hapustransklik(ActionEvent event) {
        Alert a=new Alert(Alert.AlertType.CONFIRMATION,
                "Hapus Transaksi?",ButtonType.YES,ButtonType.NO);
        a.showAndWait();
        if(a.getResult()==ButtonType.YES){
           //hapus data detil
           FXMLDocumentController.dtpesandetil.
                   deleteall(txtnojual.getText());
           //hapus data master
           FXMLDocumentController.dtpesan.delete(txtnojual.getText());
           Alert b=new Alert(Alert.AlertType.INFORMATION,
                   "Transaksi berhasil dihapus", ButtonType.OK);
           b.showAndWait();
           } else {
               Alert b=new Alert(Alert.AlertType.ERROR,
                       "Transaksi gagal dihapus", ButtonType.OK);
               b.showAndWait();               
           }    
           showdatadetil();
           buattrans=false;
           }

    @FXML
    private void pilihcustklik(ActionEvent event) {
        try{
        FXMLLoader loader=new FXMLLoader(getClass().getResource("FXMLPilihCust.fxml"));    
        Parent root = (Parent)loader.load();
        FXMLPilihCustController isidt=(FXMLPilihCustController)loader.getController();
        Scene scene = new Scene(root);
        Stage stg=new Stage();
        stg.initModality(Modality.APPLICATION_MODAL);
        stg.setResizable(false);
        stg.setIconified(false);
        stg.setScene(scene);
        stg.showAndWait();
        if(isidt.getHasil()==1){
            txtidmember.setText(isidt.getIdmemberhasil());
        }
        } catch (IOException e){   e.printStackTrace();   }
    }

    
}
